package com.example.kakaoapi

import android.content.pm.PackageManager
import android.nfc.Tag
import android.os.Bundle
import android.util.Base64
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.kakao.sdk.auth.LoginClient
import com.kakao.sdk.auth.model.OAuthToken
import com.kakao.sdk.common.KakaoSdk
import com.kakao.sdk.common.util.Utility
import com.kakao.sdk.talk.TalkApiClient
import com.kakao.sdk.template.model.Link
import com.kakao.sdk.template.model.TextTemplate
import java.security.MessageDigest
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val defaultText = TextTemplate(
            text = "자동응답기".trimIndent(),
            link = Link(
                webUrl = "https://developers.kakao.com",
                mobileWebUrl = "https://developers.kakao.com"
            )
        )

        btn_log.setOnClickListener {

            // 로그인 조합 예제
           // 로그인 공통 callback 구성
            val callback: (OAuthToken?, Throwable?) -> Unit = { token, error ->
                if (error != null) {
                    Log.e("TAG", "로그인 실패", error)
                }
                else if (token != null) {
                    Log.i("TAG", "로그인 성공 ${token.accessToken}")
                }
            }

         // 카카오톡이 설치되어 있으면 카카오톡으로 로그인, 아니면 카카오계정으로 로그인
            if (LoginClient.instance.isKakaoTalkLoginAvailable(this)) {
                LoginClient.instance.loginWithKakaoTalk(this, callback = callback)
            } else {
                LoginClient.instance.loginWithKakaoAccount(this, callback = callback)
            }

            // 카카오톡 프로필 가져오기
            TalkApiClient.instance.profile { profile, error ->
                if (error != null) {
                    Log.e("TAG", "카카오톡 프로필 가져오기 실패", error)
                }
                else if (profile != null) {
                    Log.i("TAG", "카카오톡 프로필 가져오기 성공" +
                            "\n닉네임: ${profile.nickname}" +
                            "\n프로필사진: ${profile.thumbnailUrl}" +
                            "\n국가코드: ${profile.countryISO}")
                }
            }



            TalkApiClient.instance.sendDefaultMemo(defaultText) { error ->
                if (error != null) {
                    Log.e("TAG", "나에게 보내기 실패", error)
                } else {
                    Log.i("TAG", "나에게 보내기 성공")
                }
            }

            // 카카오톡 친구 목록 가져오기
            TalkApiClient.instance.friends { friends, error ->
                if (error != null) {
                    Log.e("TAG", "카카오톡 친구 목록 가져오기 실패", error)
                }
                else {
                    Log.d("TAG", "카카오톡 친구 목록 가져오기 성공 \n${friends!!.elements.joinToString("\n")}")


                }
            }
        }


    }
}

