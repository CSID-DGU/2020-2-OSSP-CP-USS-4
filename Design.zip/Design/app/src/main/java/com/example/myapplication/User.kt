package com.example.myapplication

class User(val profile: Int, val name: String, val state: String)